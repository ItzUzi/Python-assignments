def add_user(users):
    '''
    Adds user to the users dictionary, does not take previous user entries
    :param users: dictionary to be appended
    :return: None
    '''
    new_user_name = input("Enter a new user-name: ")

    if new_user_name in users:
        print("User name already exists")
        return add_user(users)
    else:
        new_psswd = input("Enter password for %s: " % new_user_name)
        users[new_user_name] = new_psswd
        print("New User List: \n{}".format(users))
        return


def admin_commands(users, user_name):
    '''
    Menu for admin commands, takes user input to make selections
    :param users: users dictionary to be edited
    :param user_name: user_name of admin
    :return: None
    '''

    while True:
        print("\n\nADMIN COMMANDS:")
        print("1) Change Password")
        print("2) Add user")
        print("3) List users")
        print("4) EXIT")

        usr_input = input("Select an option: ")

        if usr_input == '1':
            change_login(users, user_name)
        elif usr_input == '2':
            add_user(users)
        elif usr_input == '3':
            print("\nUser List: {}".format(users))
        elif usr_input == '4':
            return
        else:
            print("Enter a valid option")


def change_login(users, user_name):
    '''
    Changes password for user
    :param users: dictionary to be changed
    :param user_name: username of account who's password is being changed
    :return: None
    '''
    old_psswrd = users[user_name]
    new_psswrd = input("new password to replace the previous one: ")
    users[user_name] = new_psswrd
    print("Replaced '%s' with the new password '%s'"%(old_psswrd, new_psswrd))


def login(users):
    '''
    Login menu, user selects username and inputs password for the username
    :param users: dictionary being used
    :return: None
    '''
    print("User list: \n{}".format(users), end='\n\n')
    print("\n\nLOGIN: \n")
    admin_user = False
    user_name = input("Enter your username: ")

    if user_name not in users.keys():
        print("Username not found!")
        return login(users)

    if user_name == 'admin' or users['admin'] == user_name:
        user_name = users['admin']
        admin_user = True

    for i in range(2, -1, -1):
        pswrd = input("Enter your password for %s: " % user_name)

        if pswrd != users[user_name]:
            print("%d attempts remaining!" % i)
        else:
            break

    else:
        print("Login Failed")
        return login(users)

    print("Login successful")

    if not admin_user:
        while True:
            print("Would you like to change your password?")
            usr_input = input("y/n: ")
            if usr_input == 'y':
                change_login(users, user_name)
            elif usr_input == 'n':
                return
            else:
                print("Enter a valid option")
    else:
        admin_commands(users, user_name)


def main():
    # creates username list
    user_list = {"Jesse", "Alex", "Betty", "Kim"}
    users = {}

    # makes a random user admin
    for name in user_list:
        users['admin'] = name
        break

    # asks user to input passwords for respective usernames
    for name in user_list:
        users[name] = input("Enter a password for %s: " % name)

    usr_input = 'n'

    """
    while user wants to keep making account operations
    don't quit the program
    """

    while usr_input != 'y':
        login(users)
        while True:
            print("Exit Program?")
            usr_input = input("y/n: ")
            if usr_input == 'y' or usr_input == 'n':
                break
            else:
                print("Enter valid option")


if __name__ == '__main__':
    main()
