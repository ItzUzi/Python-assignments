def counts(shell):
    return int(input("{}: ".format(shell)))     # returns the amount inputted by user


def get_totals(shell, shell_count, shell_price):    # returns tuple of shell variables
    total = list()
    total.append(shell)
    total.append(shell_count)
    total.append(shell_price)
    return tuple(total)


def print_total(shell_totals):      # prints all shell variables
    shell_name = shell_totals[0]
    shell_amount = shell_totals[1]
    shell_price = shell_totals[2] * shell_totals[1]

    print("shell: {}\namount: {}\ntotal price: {}".format(
        shell_name, shell_amount, shell_price), end='\n\n')


def main():
    shells = ['Puka', 'Cone', 'Driftwood', 'Sea Glass', 'Starfish']
    shell_price = [1, 1.5, .50, 2.0, 2.5]
    shell_count = list()        # creates list for user inputted amounts of shells

    print("Enter how many of each shell you collected: ")
    for shell in shells:
        shell_count.append(counts(shell))
    shell_totals = list()

    for i in range(len(shells)):
        shell_totals.append(get_totals(shells[i],
                            shell_count[i], shell_price[i]))
    print()
    for obj in shell_totals:
        print_total(obj)


if __name__ == '__main__':
    main()
