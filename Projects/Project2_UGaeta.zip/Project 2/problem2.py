from digitprint import *
import turtle


def barcode_print(zip_code):
    '''
    Calls printing methods from digitprint
    :param zip_code: zip_code with check_sum
    :return: None
    '''
    tur = turtle.Turtle()   # Creates turtle object and edits
    tur.penup()             # its properties
    tur.color('black')
    tur.setpos(-200, 0)
    tur.speed(0)

    print_start_stop(tur)

    for num in zip_code:

        if int(num) == 0:
            print0(tur)
            continue

        elif int(num) == 1:
            print1(tur)
            continue

        elif int(num) == 2:
            print2(tur)
            continue

        elif int(num) == 3:
            print3(tur)
            continue

        elif int(num) == 4:
            print4(tur)
            continue

        elif int(num) == 5:
            print5(tur)
            continue

        elif int(num) == 6:
            print6(tur)
            continue

        elif int(num) == 7:
            print7(tur)
            continue

        elif int(num) == 8:
            print8(tur)
            continue

        else:
            print9(tur)

    print_start_stop(tur)

    tur.hideturtle()


def zip_sum(zip_code):
    '''
    Adds all of the zip codes digits together and
    :param zip_code: user inputted zip_code from previous method call
    :return: zip_code with check_sum implemented
    '''
    total_sum = 0
    for digit in zip_code:

        if int(digit) == 0:
            total_sum += 11
            continue

        for i in range(1, 10, 1):
            if int(digit) == i:
                total_sum += int(digit)
    # takes check sum of zip_code (in this case check_sum = 10 - (sum mod 10))
    check_sum = 10 - (total_sum % 10)
    zip_code += str(check_sum)
    return zip_code


def take_zip_error_check(usr_input):

    '''
    Checks for possible invalid formatting of desired
    zip code
    :param usr_input: input being checked
    :return: -1 if an invalid input, None if input is valid
    '''

    # Checks if there is a hyphen in index 5 and zip code is
    # appropriate length
    if usr_input[5] != '-' or len(usr_input) != 10:
        print("invalid format")
        return -1

    # Checks all entries to see if everything is a digit
    for num in usr_input:
        if num == usr_input[5]:
            continue

        if not num.isdigit():
            print("invalid format")
            return -1


def take_zip():
    '''
    Asks user to input a properly formatted zip code
    calls take_zip_error_check() in order to check if proper formatting has been used
    :return: zip_code
    '''
    usr_input = input("Input a zip code in ZIP+4 format\nie. 12345-1234\n")
    while take_zip_error_check(usr_input) == -1:
        return take_zip()

    arr = usr_input.split('-')
    zip_code = ''

    for symbol in arr:
        zip_code += symbol

    return zip_code


def main():
    zip_code = take_zip()
    zip_code = zip_sum(zip_code)

    barcode_print(zip_code)

    input("Press enter to end program")


if __name__ == '__main__':
    main()
