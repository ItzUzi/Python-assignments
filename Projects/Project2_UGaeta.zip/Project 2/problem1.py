def get_num_of_character(usr_input):
    counter = 0
    for symbol in usr_input:
        counter += 1
    return counter


def output_without_whitespace(usr_input):
    output = ""
    str_arr = usr_input.split()
    for i in str_arr:
        output += i
    return output
        

def get_acronym(usr_input):
    output = ""
    str_arr = usr_input.split()
    for i in str_arr:
        i = i.capitalize()
        output += i[0]
    output.capitalize()
    return output


def get_safe(plain_text, key):
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    counter = 0
    cipher_text = ""
    for i in plain_text:
        # if counter is greater than length of alphabet
        # string contains unaccepted characters
        while counter < len(alphabet):
            # Checks each index of alphabet in order for match
            if i == alphabet[counter]:
                break
            else:
                counter += 1
            # Once found adds key with same index into cipher text
        else:
            return "Invalid String"
        cipher_text += key[counter]
        counter = 0
            
    return cipher_text


def main():
    usr_input = input("Enter a sentence or phrase: ")
    print("You entered:", usr_input)
    char_num = get_num_of_character(usr_input)
    print("Number of characters:", char_num)
    no_white = output_without_whitespace(usr_input)
    print("String with no whitespace:", no_white)
    usr_input = input("Enter a phrase to generate an acronym: ")
    acrnm = get_acronym(usr_input)
    print("The acronym is:", acrnm)
    key = 'BPZHGOCVJDQSWKIMLUTNERYAXF'
    encrypted_acrnm = get_safe(acrnm, key)
    print("Encrypting {} using the key {}: {}".format(acrnm, key, encrypted_acrnm))


if __name__ == '__main__':
    main()
    
'''
Output

Enter a sentence or phrase: The only thing we have to fear is fear itself.
You entered: The only thing we have to fear is fear itself.
Number of characters: 46
String with no whitespace: Theonlythingwehavetofearisfearitself.
Enter a phrase to generate an acronym: random access memory
The acronym is: RAM
Encrypting RAM using the key BPZHGOCVJDQSWKIMLUTNERYAXF: UBW

Enter a sentence or phrase: You're gonna go far kid
You entered: You're gonna go far kid
Number of characters: 23
String with no whitespace: You'regonnagofarkid
Enter a phrase to generate an acronym: Wilson high school
The acronym is: WHS
Encrypting WHS using the key BPZHGOCVJDQSWKIMLUTNERYAXF: YVT


Enter a sentence or phrase: The duck walked up to the lemonade stand
You entered: The duck walked up to the lemonade stand
Number of characters: 40
String with no whitespace: Theduckwalkeduptothelemonadestand
Enter a phrase to generate an acronym: Cal Poly Pomona
The acronym is: CPP
Encrypting CPP using the key BPZHGOCVJDQSWKIMLUTNERYAXF: ZMM
'''