def long_line(tur, counter):
    '''
    Creates long line for barcode
    :param tur: turtle object
    :param counter: counts how many times called recursively
    :return: None
    '''
    rect_height = 30
    rect_width = 3

    if counter == 0:
        return None
    intro_x = tur.pos()[0]

    tur.begin_fill()
    tur.right(90)
    tur.forward(rect_height)
    tur.left(90)
    tur.forward(rect_width)
    tur.left(90)
    tur.forward(rect_height)
    tur.left(90)
    tur.forward(rect_width)
    tur.end_fill()
    tur.right(180)

    tur.setpos(intro_x + 5, 0)

    return long_line(tur, counter - 1)


def short_line(tur, counter):
    '''
    Creates short line for barcode
    :param tur: turtle object
    :param counter: counts how many times called recursively
    :return: None
    '''
    rect_height = 15
    rect_width = 3

    if counter == 0:
        return None

    intro_x = tur.pos()[0]

    # starts in lower y position
    tur.sety(-rect_height)

    # dimensions for rectangle
    tur.begin_fill()
    tur.right(90)
    tur.forward(rect_height)
    tur.left(90)
    tur.forward(rect_width)
    tur.left(90)
    tur.forward(rect_height)
    tur.left(90)
    tur.forward(rect_width)
    tur.end_fill()
    tur.right(180)

    tur.setpos(intro_x + 5, 0)

    return short_line(tur, counter - 1)

# call methods for their respective symbols


def print0(tur):
    long_line(tur, 2)
    short_line(tur, 3)


def print1(tur):
    short_line(tur, 3)
    long_line(tur, 2)


def print2(tur):
    short_line(tur, 2)
    long_line(tur, 1)
    short_line(tur, 1)
    long_line(tur, 1)


def print3(tur):
    short_line(tur, 2)
    long_line(tur, 2)
    short_line(tur, 1)


def print4(tur):
    short_line(tur, 1)
    long_line(tur, 1)
    short_line(tur, 2)
    long_line(tur, 1)


def print5(tur):
    short_line(tur, 1)
    long_line(tur, 1)
    short_line(tur, 1)
    long_line(tur, 1)
    short_line(tur, 1)


def print6(tur):
    short_line(tur, 1)
    long_line(tur, 2)
    short_line(tur, 2)


def print7(tur):
    long_line(tur, 1)
    short_line(tur, 3)
    long_line(tur, 1)


def print8(tur):
    long_line(tur, 1)
    short_line(tur, 2)
    long_line(tur, 1)
    short_line(tur, 1)


def print9(tur):
    long_line(tur, 1)
    short_line(tur, 1)
    long_line(tur, 1)
    short_line(tur, 2)


def print_start_stop(tur):
    long_line(tur, 1)
