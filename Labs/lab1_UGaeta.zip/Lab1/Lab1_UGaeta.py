#Name: Uziel Gaeta
#Lab 1 - Task 2
#THis program will print a few lines of greeting
print("Hello, World")
print("Welcome to CS2520: Python for Programmers")
print("Enjoy your first lab experience.")

"""
Hello, World
Welcome to CS2520: Python for Programmers
Enjoy your first lab experience.
"""